"""
Online Quiz System
-------------------
A Flask web app with two flows:

  Student: enter name -> answer MCQs -> see score + answer review
  Admin:   sign in -> add / edit / delete questions -> view all results

Questions and results are stored in a local SQLite database (quiz.db),
created automatically the first time the app runs.
"""

from datetime import datetime
from functools import wraps

from flask import Flask, flash, redirect, render_template, request, session, url_for

from database import get_db_connection, init_db

app = Flask(__name__)
app.secret_key = "change-this-secret-key-before-deploying"  # used to sign session cookies

# NOTE: hardcoded for simplicity in this project. Change these, or move
# them to an environment variable / proper user table, before going live.
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"


def admin_required(view_func):
    """Decorator that blocks a route unless an admin is logged in."""

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Please sign in as admin first.", "error")
            return redirect(url_for("admin_login"))
        return view_func(*args, **kwargs)

    return wrapped


# ---------------------------------------------------------------------------
# Home
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------------------------
# Student flow: name -> quiz -> result
# ---------------------------------------------------------------------------

@app.route("/quiz/start", methods=["GET", "POST"])
def quiz_start():
    if request.method == "POST":
        name = request.form.get("student_name", "").strip()
        if not name:
            flash("Please enter your name to start the quiz.", "error")
            return redirect(url_for("quiz_start"))
        session["student_name"] = name
        return redirect(url_for("take_quiz"))
    return render_template("student_login.html")


@app.route("/quiz")
def take_quiz():
    if "student_name" not in session:
        return redirect(url_for("quiz_start"))

    conn = get_db_connection()
    questions = conn.execute("SELECT * FROM questions ORDER BY id").fetchall()
    conn.close()

    if not questions:
        flash("No questions available right now. Please contact the admin.", "error")
        return redirect(url_for("index"))

    return render_template("quiz.html", questions=questions, student_name=session["student_name"])


@app.route("/quiz/submit", methods=["POST"])
def submit_quiz():
    if "student_name" not in session:
        return redirect(url_for("quiz_start"))

    conn = get_db_connection()
    questions = conn.execute("SELECT * FROM questions ORDER BY id").fetchall()

    score = 0
    review = []
    for q in questions:
        selected = request.form.get(f"q_{q['id']}")
        is_correct = selected == q["correct_option"]
        if is_correct:
            score += 1
        review.append(
            {
                "question_text": q["question_text"],
                "options": {
                    "A": q["option_a"],
                    "B": q["option_b"],
                    "C": q["option_c"],
                    "D": q["option_d"],
                },
                "selected": selected,
                "correct": q["correct_option"],
                "is_correct": is_correct,
            }
        )

    total = len(questions)
    student_name = session["student_name"]

    conn.execute(
        "INSERT INTO results (student_name, score, total_questions, date_taken) VALUES (?, ?, ?, ?)",
        (student_name, score, total, datetime.now().strftime("%Y-%m-%d %H:%M")),
    )
    conn.commit()
    conn.close()

    # Stash the result for the /result page, then clear the in-progress name.
    session["last_result"] = {
        "student_name": student_name,
        "score": score,
        "total": total,
        "review": review,
    }
    session.pop("student_name", None)

    return redirect(url_for("show_result"))


@app.route("/result")
def show_result():
    result = session.get("last_result")
    if not result:
        return redirect(url_for("index"))
    percentage = round((result["score"] / result["total"]) * 100) if result["total"] else 0
    return render_template("result.html", result=result, percentage=percentage)


# ---------------------------------------------------------------------------
# Admin flow: sign in -> manage questions -> view results
# ---------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["is_admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Invalid admin username or password.", "error")
    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("index"))


@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = get_db_connection()
    questions = conn.execute("SELECT * FROM questions ORDER BY id").fetchall()
    conn.close()
    return render_template("admin_dashboard.html", questions=questions)


@app.route("/admin/questions/add", methods=["GET", "POST"])
@admin_required
def add_question():
    if request.method == "POST":
        data = _extract_question_form(request.form)
        if data is None:
            return redirect(url_for("add_question"))
        conn = get_db_connection()
        conn.execute(
            """INSERT INTO questions
               (question_text, option_a, option_b, option_c, option_d, correct_option)
               VALUES (?, ?, ?, ?, ?, ?)""",
            data,
        )
        conn.commit()
        conn.close()
        flash("Question added.", "success")
        return redirect(url_for("admin_dashboard"))

    return render_template("question_form.html", question=None, form_action=url_for("add_question"))


@app.route("/admin/questions/edit/<int:question_id>", methods=["GET", "POST"])
@admin_required
def edit_question(question_id):
    conn = get_db_connection()

    if request.method == "POST":
        data = _extract_question_form(request.form)
        if data is None:
            conn.close()
            return redirect(url_for("edit_question", question_id=question_id))
        conn.execute(
            """UPDATE questions
               SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=?
               WHERE id=?""",
            (*data, question_id),
        )
        conn.commit()
        conn.close()
        flash("Question updated.", "success")
        return redirect(url_for("admin_dashboard"))

    question = conn.execute("SELECT * FROM questions WHERE id=?", (question_id,)).fetchone()
    conn.close()
    if question is None:
        flash("That question no longer exists.", "error")
        return redirect(url_for("admin_dashboard"))

    return render_template(
        "question_form.html", question=question, form_action=url_for("edit_question", question_id=question_id)
    )


@app.route("/admin/questions/delete/<int:question_id>", methods=["POST"])
@admin_required
def delete_question(question_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM questions WHERE id=?", (question_id,))
    conn.commit()
    conn.close()
    flash("Question deleted.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/results")
@admin_required
def admin_results():
    conn = get_db_connection()
    results = conn.execute("SELECT * FROM results ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("admin_results.html", results=results)


def _extract_question_form(form):
    """Pull + validate the add/edit question form. Returns a tuple ready
    for the SQL statement, or None (and flashes an error) if invalid."""
    question_text = form.get("question_text", "").strip()
    option_a = form.get("option_a", "").strip()
    option_b = form.get("option_b", "").strip()
    option_c = form.get("option_c", "").strip()
    option_d = form.get("option_d", "").strip()
    correct_option = form.get("correct_option", "").strip().upper()

    if not all([question_text, option_a, option_b, option_c, option_d]):
        flash("Please fill in the question and all four options.", "error")
        return None
    if correct_option not in ("A", "B", "C", "D"):
        flash("Please choose which option is correct.", "error")
        return None

    return (question_text, option_a, option_b, option_c, option_d, correct_option)


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
