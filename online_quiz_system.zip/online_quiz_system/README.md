# Online Quiz System

A simple web-based Online Quiz System built with **Flask** + **SQLite**.

* Students take an MCQ test and instantly see their **Result and Score**.
* Admin can **add / edit / delete questions** — the question bank lives in a
  database, not hardcoded in the code — and can view every student's score
  history.

## Project structure

```
online_quiz_system/
├── app.py                 # All Flask routes (student + admin)
├── database.py             # SQLite connection + table setup + sample questions
├── requirements.txt
├── quiz.db                 # Created automatically on first run
├── static/
│   └── style.css
└── templates/
    ├── base.html            # Shared layout (header, footer, flash messages)
    ├── index.html           # Home page
    ├── student_login.html   # Student enters their name
    ├── quiz.html            # The MCQ test
    ├── result.html          # Score + answer review
    ├── admin_login.html
    ├── admin_dashboard.html # Question bank: list / add / edit / delete
    ├── question_form.html   # Shared Add + Edit question form
    └── admin_results.html   # Every student attempt, with score %
```

## Setup

1. Make sure you have **Python 3.8+** installed.
2. (Recommended) create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Run it

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

The database (`quiz.db`) is created automatically the first time you run
the app, with 5 sample questions already in it so the quiz isn't empty.

## Using it

**As a student**
1. Click "Start the quiz" on the home page.
2. Enter your name.
3. Answer every question (each one is a set of 4 options, like an OMR
   answer sheet — click a circle to mark your answer).
4. Submit. You'll see your score, percentage, and a review of which
   answers were right or wrong.

**As an admin**
1. Click "Admin" on the home page.
2. Sign in with the default credentials:
   - Username: `admin`
   - Password: `admin123`
3. From the **Question bank** you can add new questions, edit existing
   ones, or delete them.
4. **Mark book** shows every attempt any student has made, with their
   score and percentage.

> ⚠️ **Before deploying this anywhere public:** change `ADMIN_USERNAME`,
> `ADMIN_PASSWORD`, and `app.secret_key` in `app.py` — they're set to
> simple defaults for local development only.

## Ideas to extend this project

- Add a countdown timer per question or per quiz.
- Add question categories/subjects and let the student pick one before
  starting.
- Require students to log in (instead of just typing a name) so each
  person can only attempt a quiz once.
- Add pagination or search to the admin question bank once it grows large.
- Deploy with a production server (e.g. `gunicorn app:app`) instead of
  the Flask development server.
