"""
Database layer for the Online Quiz System.
Uses plain sqlite3 (no extra dependency) with two tables:
  - questions: the MCQ question bank, editable by the admin
  - results:   one row per quiz attempt (student name, score, date)
"""

import os
import sqlite3

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quiz.db")


def get_db_connection():
    """Open a new connection with rows accessible by column name."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables if they don't exist yet, and seed a few sample
    questions the first time the app runs so the quiz isn't empty."""
    conn = get_db_connection()

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_text TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_option TEXT NOT NULL CHECK (correct_option IN ('A', 'B', 'C', 'D'))
        )
        """
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name TEXT NOT NULL,
            score INTEGER NOT NULL,
            total_questions INTEGER NOT NULL,
            date_taken TEXT NOT NULL
        )
        """
    )
    conn.commit()

    existing = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
    if existing == 0:
        sample_questions = [
            (
                "What is the capital of India?",
                "Mumbai", "New Delhi", "Pune", "Chennai", "B",
            ),
            (
                "This quiz application's backend is written in which language?",
                "Java", "C++", "Python", "PHP", "C",
            ),
            (
                "Who originally created the Python programming language?",
                "Guido van Rossum", "James Gosling", "Dennis Ritchie", "Bjarne Stroustrup", "A",
            ),
            (
                "Which keyword defines a function in Python?",
                "func", "def", "function", "define", "B",
            ),
            (
                "HTML stands for:",
                "Hyper Text Markup Language", "High Text Markup Language",
                "Hyper Transfer Markup Language", "Hyper Text Modern Language", "A",
            ),
        ]
        conn.executemany(
            """INSERT INTO questions
               (question_text, option_a, option_b, option_c, option_d, correct_option)
               VALUES (?, ?, ?, ?, ?, ?)""",
            sample_questions,
        )
        conn.commit()

    conn.close()
